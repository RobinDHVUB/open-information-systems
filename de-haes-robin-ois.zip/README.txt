The SPARQL queries in de-haes-robin-queries-sparql.txt should be the same as the ones mentioned in the PDF report.

In case of any issues all files in this zip can also be found at: https://github.com/RobinDHVUB/open-information-systems